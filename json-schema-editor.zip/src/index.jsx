window.JSONSchemaEditor = function(element,options) {
	if (!(element instanceof Element)) {
		throw new Error('element should be an instance of Element');
	}
	options = options||{};
	this.element = element;
	this.options = options;
	this.init();
};

JSONSchemaEditor.prototype = {
	// necessary since we remove the ctor property by doing a literal assignment. Without this
	// the $isplainobject function will think that this is a plain object.
	constructor: JSONSchemaEditor,
	init: function() {
		var self = this;
		var data = this.options.startval || {};

		this.react = ReactDOM.render(
			<SchemaObject onChange={this.onChange} data={data}/>,
			self.element
		);
		this.callbacks = {};
	},
	on: function(event, callback) {
		this.react.on(event, callback);
	},
	onChange: function() {
	},
	getValue: function() {
		return this.react.export();
	},
	setValue: function(data) {
		var self = this;
		this.react = ReactDOM.render(
			<SchemaObject onChange={this.onChange} data={data}/>,
			self.element
		);
	}
}

var shortNumberStyle = {
	width: '50px'
}

var SchemaString = React.createClass({
	getInitialState: function() {
		var state = this.props.data;
		state.hasEnum = !!state.enum;
		return state
	},
	componentDidUpdate: function() {
		this.props.onChange();
	},
	export: function() {
		return {
			type: 'string',
			format: this.state.format,
			pattern: !!this.state.pattern ? this.state.pattern : undefined,
			enum: this.state.enum
		};
	},
	change: function(event) {
		this.state[event.target.name] = event.target.value;
		this.setState(this.state);
	},
	changeBool: function(event) {
		this.state[event.target.name] = event.target.checked;
		this.setState(this.state);
	},
	changeEnum: function(event) {
		var arr = event.target.value.split('\n');
		if (arr.length == 1 && !arr[0]) {
			arr = undefined;
		}
		this.state[event.target.name] = arr
		this.setState(this.state);
	},
	render: function() {
		var settings;
		if (this.state.hasEnum) {
			settings = <div>
				<label className="media-object" htmlFor="enum">Enum (one value per line):</label>
				<textarea onChange={this.changeEnum} name="enum" value={(this.state.enum||[]).join('\n')} />
				</div>
		} else {
			settings = <span>
				Pattern: <input name="pattern" type="text" value={this.state.pattern} onChange={this.change} />
				</span>
		}
		return (
			<div>
				Format:
				<select name="format" onChange={this.change} value={this.state.format}>
					<option value=""></option>
					<option value="color">color</option>
					<option value="date">date</option>
					<option value="datetime">datetime</option>
					<option value="datetime-local">datetime-local</option>
					<option value="email">email</option>
					<option value="month">month</option>
					<option value="number">number</option>
					<option value="range">range</option>
					<option value="tel">tel</option>
					<option value="text">text</option>
					<option value="textarea">textarea</option>
					<option value="time">time</option>
					<option value="url">url</option>
					<option value="week">week</option>
				</select>
				Enum: <input name="hasEnum" type="checkbox" checked={this.state.hasEnum} onChange={this.changeBool}  />
				{settings}
			</div>
		);
	}
});

var SchemaBoolean = React.createClass({
	export: function() {
		return {
			type: 'boolean',
			format: 'checkbox'
		}
	},
	render() {
		return (
			<div></div>
		);
	}
})

var SchemaNumber = React.createClass({
	getInitialState: function() {
		return this.props.data;
	},
	componentDidUpdate: function() {
		this.props.onChange();
	},
	change: function(event) {
		this.state[event.target.name] = event.target.value;
		this.setState(this.state);
	},
	export: function() {
		var o = JSON.parse(JSON.stringify(this.state));
		o.type = 'number';
		delete o.name;
		return o;
	},
	render: function() {
		return (
			<div>
				Min: <input name="minimum" type="number" value={this.state.minimum} onChange={this.change} />
				Max: <input name="maximum" type="number" value={this.state.maximum} onChange={this.change} />
			</div>
		);
	}
});

var SchemaText = React.createClass({
	getInitialState: function() {
		return this.props.data;
	},
	componentDidUpdate: function() {
		this.props.onChange();
	},
	change: function(event) {
		this.state[event.target.name] = event.target.value;
		this.setState(this.state);
	},
	export: function() {
		var o = JSON.parse(JSON.stringify(this.state));
		o.type = 'number';
		delete o.name;
		return o;
	},
	render: function() {
		return (
			<div>
			</div>
		);
	}
});

var SchemaTextarea = React.createClass({
	getInitialState: function() {
		return this.props.data;
	},
	componentDidUpdate: function() {
		this.props.onChange();
	},
	change: function(event) {
		this.state[event.target.name] = event.target.value;
		this.setState(this.state);
	},
	export: function() {
		var o = JSON.parse(JSON.stringify(this.state));
		o.type = 'number';
		delete o.name;
		return o;
	},
	render: function() {
		return (
			<div>
			</div>
		);
	}
});

var SchemaCheckboxes = React.createClass({
	getInitialState: function() {
		return this.propsToState(this.props)
	},
	propsToState: function(props) {
		var data = props.data;
		if(data.hasOwnProperty('enum') && data.enum.length > 0) {
			data.enum = data.enum.join('|');
		} else {
		  data.enum = '';
	  }
		return data
	},
	componentDidUpdate: function() {
		this.props.onChange();
	},
	handleChange: function(event) {
		this.state.enum = event.target.value;
		this.setState(this.state);
	},
	export: function() {
		var arr = [];
		if(this.state.enum.length > 0) {
			arr = this.state.enum.split('|');
		}
		return {
			type: "string",
			format: "checkboxes",
			enum: arr
		};
	},
	render: function() {
		var self = this;
		return (
			<div className="row">
				<div className="col-md-10 col-lg-10">
				  <input type="text" name="titlemap" className="form-control" onChange={self.handleChange} value={self.state.enum} placeholder="選択肢を「|」区切りで入力して下さい" />
				</div>
			</div>
		);
	}
});

var SchemaRadios = React.createClass({
	getInitialState: function() {
		return this.propsToState(this.props)
	},
	propsToState: function(props) {
		var data = props.data;
		if(data.hasOwnProperty('enum') && data.enum.length > 0) {
			data.enum = data.enum.join('|');
		} else {
		  data.enum = '';
	  }
		return data
	},
	componentDidUpdate: function() {
		this.props.onChange();
	},
	handleChange: function(event) {
		this.state.enum = event.target.value;
		this.setState(this.state);
	},
	export: function() {
		var arr = [];
		if(this.state.enum.length > 0) {
			arr = this.state.enum.split('|');
		}
		return {
			type: "string",
			format: "radios",
			enum: arr
		};
	},
	render: function() {
		var self = this;
		return (
			<div className="row">
				<div className="col-md-10 col-lg-10">
				  <input type="text" name="titlemap" className="form-control" onChange={self.handleChange} value={self.state.enum} placeholder="選択肢を「|」区切りで入力して下さい" />
				</div>
			</div>
		);
	}
});

var SchemaSelect = React.createClass({
	getInitialState: function() {
		return this.propsToState(this.props)
	},
	propsToState: function(props) {
		var data = props.data;
		if(data.hasOwnProperty('enum') && data.enum.length > 0) {
			data.enum = data.enum.join('|');
		} else {
		  data.enum = '';
	  }
		return data
	},
	componentDidUpdate: function() {
		this.props.onChange();
	},
	handleChange: function(event) {
		this.state.enum = event.target.value;
		this.setState(this.state);
	},
	export: function() {
		var arr = [];
		if(this.state.enum.length > 0) {
			arr = this.state.enum.split('|');
		}
		return {
			type: "string",
			format: "select",
			enum: arr
		};
	},
	render: function() {
		var self = this;
		return (
			<div className="row">
				<div className="col-md-10 col-lg-10">
				  <input type="text" name="titlemap" className="form-control" onChange={self.handleChange} value={self.state.enum} placeholder="選択肢を「|」区切りで入力して下さい" />
				</div>
			</div>
		);
	}
});

var mapping = function(name, data, changeHandler) {
	return {
		text: <SchemaText onChange={changeHandler} ref={name} data={data} />,
	  textarea: <SchemaTextarea onChange={changeHandler} ref={name} data={data} />,
		checkboxes: <SchemaCheckboxes onChange={changeHandler} ref={name} data={data} />,
	  radios: <SchemaRadios onChange={changeHandler} ref={name} data={data} />,
	  select: <SchemaSelect onChange={changeHandler} ref={name} data={data}/>,
		object: <SchemaObject onChange={changeHandler} ref={name} data={data}/>
  }[data.format];
};

var SchemaArray = React.createClass({
	getInitialState: function() {
		return this.props.data;
	},
	change: function(event) {
		console.log(this.state)
		if (event.target.type == 'checkbox') {
			this.state[event.target.name] = event.target.checked;
		}
		else if (event.target.name == 'itemtype') {
			this.state.items.type = event.target.value;
		}
		else {
			this.state[event.target.name] = event.target.value;
		}
		this.setState(this.state);
	},
	export: function() {
		//console.log(this.refs.items.state)
		return {
			items: this.refs['items'].export(),
			minItems: this.state.minItems,
			maxItems: this.state.maxItems,
			uniqueItems: (this.state.uniqueItems ? true : undefined),
			format: this.state.format,
			type: 'array'
		};
	},
	componentDidUpdate: function() {
		this.onChange();
	},
	onChange: function() {
		this.props.onChange();
	},
 	render: function() {
		var self = this;
		var optionFormStyle = {
			paddingLeft: '25px',
			paddingTop: '4px',
		};
		this.state.items = this.state.items || {type: 'string'};
		var optionForm = mapping('items', this.state.items, this.onChange);
		return (
			<div>
				Items Type:
				<select name="itemtype" onChange={this.change} value={this.state.items.type}>
						<option value="string">string</option>
						<option value="number">number</option>
						<option value="array">array</option>
						<option value="object">object</option>
						<option value="boolean">boolean</option>
					</select>
				minItems:  <input name="minItems" type="number" onChange={self.change} value={self.state.minItems}  />
				maxItems:  <input name="maxItems" type="number" onChange={self.change} value={self.state.maxItems}  />
				uniqueItems:  <input name="uniqueItems" type="checkbox" onChange={self.change} checked={self.state.uniqueItems}  />
				Format:
				<select name="format" onChange={this.change} value={this.state.format}>
					<option value=""></option>
					<option value="table">table</option>
					<option value="checkbox">checkbox</option>
					<option value="select">select</option>
					<option value="tabs">tabs</option>
				</select>
				<div>
					{optionForm}
				</div>
			</div>
		);
	}
});

var SchemaObject = React.createClass({
	getInitialState: function() {
		return this.propsToState(this.props)
	},
	propsToState: function(schema) {
		var data = schema;
		if(schema.hasOwnProperty('data')) {
			data = schema.data;
		}
		data.properties = data.properties || {}
		data.required = data.required || [];
		data.propertyItems = [];
		// convert from object to array
		data.properties = Object.keys(data.properties).map(function(name) {
			data.propertyItems.push(name);
			var item = data.properties[name];
			return item;
		})
		data.inputErrs = [];    // 记录页面入力错误
		return data
	},
	// 已加载组件收到新的参数时调用
	componentWillReceiveProps: function(newProps) {
		this.setState(this.propsToState(newProps))
	},
	deleteItem: function(event) {
		// parentElement 返回母节点
		// dataset H5自定义属性 data-xxx
		var i = event.target.parentElement.dataset.index;
		var requiredIndex = this.state.required.indexOf(this.state.propertyItems[i])
		if (requiredIndex !== -1) {
			this.state.required.splice(requiredIndex, 1)
		}
		this.state.properties.splice(i, 1);
		this.state.propertyItems.splice(i, 1);
		this.setState(this.state);
	},
	changeItem: function(event) {
		var i = event.target.parentElement.dataset.index;
		if (event.target.name == 'type') {
			if('object' === event.target.value) {
				this.state.properties[i].type = event.target.value;
				this.state.properties[i].properties = {}
				this.state.properties[i].properties['subitem_'+Date.now()] = {
					type: "string",
					format: "text",
					title: ""
				}
			} else if('checkboxes' === event.target.value
			       || 'radios' === event.target.value
						 || 'select' === event.target.value) {
        this.state.properties[i].enum = [];
			} else {
			  this.state.properties[i].type = 'string';
		  }
			this.state.properties[i].format = event.target.value;
		} else if (event.target.name == 'field') {
			this.state.properties[i].title = event.target.value;
			if(event.target.value.length == 0) {
				this.state.inputErrs.push(this.state.propertyItems[i]);
			} else if(this.state.inputErrs.indexOf(this.state.propertyItems[i]) != -1) {
				this.state.inputErrs.splice(this.state.inputErrs.indexOf(this.state.propertyItems[i]),1);
			}
		}
		this.setState(this.state);
	},
	changeRequired: function(event) {
		if (event.target.checked)
			this.state.required.push(event.target.name);
		else {
			var i = this.state.required.indexOf(event.target.name)
			this.state.required.splice(i, 1);
		}
		this.setState(this.state);
	},
	onChange: function() {
		this.props.onChange()
		this.trigger('change');
	},
	// 组件完全加载到DOM后执行
	componentDidUpdate: function() {
		this.onChange();
	},
	add: function() {
		var schemaTmp = this.export();
		this.state = this.propsToState(schemaTmp);
		this.state.properties.push({type: 'string', format: 'text', title: ''});
		this.state.propertyItems.push('subitem_'+Date.now());
		this.setState(this.state);
	},
	previews: function() {
		alert(JSON.stringify(this.export(), null, 4));
	},
	export: function() {
		var self = this;
		var properties = {};

		self.state.properties.map((value, index) => {
			var itemKey = self.state.propertyItems[index];
			if(value.title.length > 0) {
				if('text' === value.format || 'textarea' === value.format) {
					properties[itemKey] = value;
				} else if('checkboxes' === value.format || 'radios' === value.format || 'select' === value.format) {
					properties[itemKey] = self.refs['subitem'+index].export();
					properties[itemKey].title = value.title;
				} else {
					// Object
					if (typeof self.refs['subitem'+index] != 'undefined') {
						properties[itemKey] = self.refs['subitem'+index].export();
						properties[itemKey].title = value.title;
					}
				}
			}
		});

		return {
			type: 'object',
			format: 'object',
			properties: properties,
			required: this.state.required.length ? this.state.required : []
		};
	},
	on: function(event, callback) {
		this.callbacks = this.callbacks || {};
		this.callbacks[event] = this.callbacks[event] || [];
		this.callbacks[event].push(callback);

		return this;
	},
	trigger: function(event) {
		if (this.callbacks && this.callbacks[event] && this.callbacks[event].length) {
			for (var i=0; i<this.callbacks[event].length; i++) {
				this.callbacks[event][i]();
			}
		}

		return this;
	},
	render: function() {
		var self = this;
		return (
		<div className="panel panel-default">
			<div className="panel-body">
				{this.state.properties.map((value, index) => {
					var itemKey = self.state.propertyItems[index]
					var copiedState = JSON.parse(JSON.stringify(self.state.properties[index]));
		 			var optionForm = mapping('subitem' + index, copiedState, self.onChange);
					return <div key={index}>
						<div className="col-md-12 col-lg-12">
							<div className="form-inline">
                <div className={self.state.inputErrs.indexOf(itemKey) != -1?"form-group has-error":"form-group"} data-index={index}>
                  <label className="sr-only" htmlFor={"input_"+itemKey}>input</label>
                  <input type="text" name="field" className="form-control" id={"input_"+itemKey} onChange={self.changeItem} value={value.title} />
                </div>
								<div className="form-group media-right" data-index={index}>
									<label className="sr-only" htmlFor={"select_"+itemKey}>input</label>
									<select name="type" className="form-control" id={"select_"+itemKey} onChange={self.changeItem} value={value.format}>
										<option value="text">テキスト</option>
										<option value="textarea">テキストエリア</option>
										<option value="checkboxes">チェックボックス</option>
										<option value="radios">ラジオ</option>
										<option value="select">プルダウン</option>
										<option value="object">オブジェクト</option>
									</select>
								</div>
                <div className="checkbox  media-right"><label>
                  <input type="checkbox" name={itemKey} onChange={self.changeRequired} checked={self.state.required.indexOf(itemKey) != -1} /> Required
                </label></div>
								<div className="form-group media-right" data-index={index}>
                  <button type="button" id={'btn_'+itemKey} className="btn btn-default" onClick={self.deleteItem}>
                    <span className="glyphicon glyphicon-remove"></span>
                  </button>
                </div>
							</div>
						</div>
						<div className="col-md-12 col-lg-12 h6">
							{optionForm}
						</div>
						<hr className="col-md-10 col-lg-10 h6" />
					</div>
				})}

	      <div className="col-md-6 col-lg-6">
	        <button className="btn btn-default navbar-text" onClick={self.add}>追加</button>
          <button className="btn btn-default navbar-text" onClick={self.previews}>Previews</button>
	      </div>
			</div>
		</div>
	);
  }
});

if (typeof module !== 'undefined' && typeof module.exports !== 'undefined')
	module.exports = window.JSONSchemaEditor;
