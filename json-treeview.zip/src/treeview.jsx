import React from 'react';
import ReactDOM from 'react-dom';

class TreeViewChild extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: props.data,
      parents: props.parents.slice() || []
    };
    this.handleToggle = this.handleToggle.bind(this);
    this.handleClick = this.handleClick.bind(this);
  }

  // 新しいパラメータがロードしたコンポーネントにパスされると、実行する。
  componentWillReceiveProps(newProps) {
    this.setState({
      data:newProps.data,
      parents: newProps.parents.slice() || []
    })
  }

  handleToggle(event) {
    let idx = event.target.parentElement.dataset.index;
    let newData = this.state.data.slice();
    newData[idx].state.expand = !this.state.data[idx].state.expand;
    this.setState(()=>({data: newData}));
  }

  handleClick(event) {
    let node = {
      id: event.target.id,
      title: this.state.data[event.target.dataset.index].title,
      parents: this.state.parents
    }
    this.props.onClick(node);
  }

  render() {
    let childli = this.state.data.map((node, index) => {
      let element = [];
      let active_class = node.state.selected?'list-group-item active':'list-group-item';
      let indent = [];
      let checked_class = "glyphicon";
      if(this.props.canChecked) {
        checked_class = node.state.checked?"icon glyphicon glyphicon-check":"icon glyphicon glyphicon-unchecked";
      }
      for(let idx=0; idx<this.props.level; idx++) {
        indent.push(<span className="indent"></span>);
      }
      if(node.children.length > 0) {
        let parents = this.state.parents.slice();
        parents.push({id:node.id,title:node.title});
        let expand_class = node.state.expand?'icon expand-icon glyphicon glyphicon-minus':'icon expand-icon glyphicon glyphicon-plus';
        element.push(<li className={active_class} id={node.id} key={node.id} data-index={index} onClick={this.handleClick}>
          {indent}
          <span className={expand_class} aria-hidden="true" onClick={this.handleToggle}></span>
          <span className={checked_class}></span>
          <span className="icon node-icon"></span>
          {node.title}
        </li>);
        if(node.state.expand) {
          let ele = <TreeViewChild key={node.id+1} onClick={this.props.onClick} data={node.children} 
                      canChecked={this.props.canChecked} canEdit={this.props.canEdit} parents={parents} level={this.props.level+1}/>
          element.push(ele);
        }
      } else {
        element.push(
          <li className={active_class} id={node.id} key={node.id} data-index={index} onClick={this.handleClick}>
            {indent}
            <span className={checked_class}></span>
            <span className="icon node-icon"></span>
            {node.title}
          </li>
        )
      }
      return element;
    });
    return childli;
  }
}

class TreeView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: props.data
    };
    this.handleClick = this.handleClick.bind(this);
  }

  // 新しいパラメータがロードしたコンポーネントにパスされると、実行する。
  componentWillReceiveProps(newProps) {
    this.setState({
      data:newProps.data
    })
  }

  getValue() {
    return this.state.data;
  }

  handleClick(node) {
    let tmpData = this.state.data.slice();
    setSelected(tmpData, node.id);
    this.setState({data: tmpData});
    this.props.onClick(node);
  }

  render() {
    return (
      <div id='tree_root' className="treeview">
        <ul className='list-group'>
          <TreeViewChild onClick={this.handleClick} data={this.state.data} 
          canChecked={this.props.canChecked} canEdit={this.props.canEdit} parents={[]} level={0}/>
        </ul>
      </div>
    );
  }
}

function setSelected(data, selectId) {
  data.forEach(element => {
    if(element.id == selectId) {
      element.state.selected = true;
    } else {
      element.state.selected = false;
    }
    if(element.children.length > 0) {
      setSelected(element.children, selectId);
    }
  });
}

window.JSONTreeView = function(element, options){
  if (!(element instanceof Element)) {
		throw new Error('element should be an instance of Element');
	}
	options = options || {};
	this.element = element;
	this.options = options;
	this.init();
}

JSONTreeView.prototype = {
	// necessary since we remove the ctor property by doing a literal assignment. Without this
	// the $isplainobject function will think that this is a plain object.
	constructor: JSONTreeView,
	init: function() {
		let self = this;
    let data = this.options.data || [];
    let canChecked = this.options.canChecked || false;
    let canEdit = this.options.canEdit || false;
    let onClick = this.options.onClick || this.onClick;

		this.react = ReactDOM.render(
			<TreeView onClick={onClick} data={data} canChecked={canChecked} canEdit={canEdit}/>,
			self.element
		);
		this.callbacks = {};
	},
	onClick: function(node) {
    // TODO
    alert(node.id + ':' + node.title);
  },
  getValue: function() {
    return this.react.getValue();
  },
	setValue: function(options) {
		this.options = options;
		this.init();
	}
}

if (typeof module !== 'undefined' && typeof module.exports !== 'undefined')
  module.exports = window.JSONTreeView;
  